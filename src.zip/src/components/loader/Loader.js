import ReactDOM from 'react-dom';

const Loader = () => {

   // const spiner = document.getElementById("spiner");
    
    return (
           // ReactDOM.createPortal(<div className='loader'></div>, spiner)      
           <p>Loading.....</p> 
    )
}

export default Loader;